package com.example.multipantallas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
